const questions = [
  {
    q: "你偏愛的氛圍？",
    options: ["清新自然", "優雅花香", "神秘木質", "濃郁東方"]
  },
  {
    q: "最適合你的場合？",
    options: ["日常通勤", "浪漫約會", "商務會議", "派對聚會"]
  }
];

const recommendations = {
  "清新自然": {
    main: { name: "Jo Malone 青檸羅勒與柑橘", img: "https://fimgs.net/mdimg/perfume/375x500.179.jpg", link: "https://www.jomalone.com.tw/" },
    alt:  { name: "Dior Sauvage", img: "https://fimgs.net/mdimg/perfume/375x500.32227.jpg", link: "https://www.dior.com/" }
  },
  "優雅花香": {
    main: { name: "Chanel N°5", img: "https://fimgs.net/mdimg/perfume/375x500.828.jpg", link: "https://www.chanel.com/" },
    alt:  { name: "Gucci Bloom", img: "https://fimgs.net/mdimg/perfume/375x500.46506.jpg", link: "https://www.gucci.com/" }
  },
  "神秘木質": {
    main: { name: "Tom Ford Oud Wood", img: "https://fimgs.net/mdimg/perfume/375x500.37509.jpg", link: "https://www.tomford.com/" },
    alt:  { name: "Armani Code", img: "https://fimgs.net/mdimg/perfume/375x500.361.jpg", link: "https://www.armani.com/" }
  },
  "濃郁東方": {
    main: { name: "YSL Black Opium", img: "https://fimgs.net/mdimg/perfume/375x500.25347.jpg", link: "https://www.yslbeauty.com/" },
    alt:  { name: "Mugler Alien", img: "https://fimgs.net/mdimg/perfume/375x500.112.jpg", link: "https://www.mugler.com/" }
  }
};

let currentQ = 0;
let answers = [];

const questionEl = document.getElementById("question");
const optionsEl = document.getElementById("options");
const nextBtn = document.getElementById("next-btn");
const resultEl = document.getElementById("result");
const recEl = document.getElementById("recommendations");

function showQuestion() {
  let q = questions[currentQ];
  questionEl.textContent = q.q;
  optionsEl.innerHTML = "";
  q.options.forEach(opt => {
    let btn = document.createElement("button");
    btn.textContent = opt;
    btn.onclick = () => { answers.push(opt); nextBtn.disabled = false; };
    optionsEl.appendChild(btn);
  });
  nextBtn.disabled = true;
}

nextBtn.addEventListener("click", () => {
  currentQ++;
  if (currentQ < questions.length) {
    showQuestion();
  } else {
    showResult();
  }
});

function showResult() {
  document.querySelector(".quiz-container").classList.add("hidden");
  resultEl.classList.remove("hidden");
  
  let last = answers[answers.length - 1];
  let rec = recommendations[last];
  if (!rec) {
    recEl.innerHTML = "<p>看來你對香水比較無感，試試無香氛的清新選擇吧！</p>";
    return;
  }
  
  recEl.innerHTML = `
    <div class="recommend-card fade-in">
      <h3>主要推薦</h3>
      <img src="${rec.main.img}" alt="${rec.main.name}">
      <p>${rec.main.name}</p>
      <a class="btn" href="${rec.main.link}" target="_blank">去購買</a>
    </div>
    <div class="recommend-card fade-in">
      <h3>次要推薦</h3>
      <img src="${rec.alt.img}" alt="${rec.alt.name}">
      <p>${rec.alt.name}</p>
      <a class="btn" href="${rec.alt.link}" target="_blank">去購買</a>
    </div>
  `;
}

showQuestion();
